import pygame
from enum import Enum
from typing import Dict

# กำหนดประเภทของยูนิต
class UnitType(Enum):
    SOLDIER = 1  # ยูนิตประเภท Soldier
    ARCHER = 2   # ยูนิตประเภท Archer

    def get_info(self) -> Dict:
        # คืนค่าข้อมูลเกี่ยวกับยูนิตแต่ละประเภท
        if self == UnitType.SOLDIER:
            return {
                "name": "Soldier",  # ชื่อของยูนิต
                "description": "Strong melee unit",  # คำอธิบาย
                "max_hp": 100,  # HP สูงสุด
                "attack": 50,  # พลังโจมตี
                "move_range": 3,  # ระยะทางที่สามารถเคลื่อนที่ได้
                "attack_range": 1  # ระยะทางโจมตี
            }
        else:  # UnitType.ARCHER
            return {
                "name": "Archer",  # ชื่อของยูนิต
                "description": "Ranged attack unit",  # คำอธิบาย
                "max_hp": 75,  # HP สูงสุด
                "attack": 40,  # พลังโจมตี
                "move_range": 2,  # ระยะทางที่สามารถเคลื่อนที่ได้
                "attack_range": 3  # ระยะทางโจมตี
            }

    @staticmethod
    def get_cost(unit_type):
        """ กำหนดค่าใช้จ่ายสำหรับยูนิตประเภทต่าง ๆ """
        costs = {
            UnitType.SOLDIER: 50,
            UnitType.ARCHER: 100,
        }
        return costs.get(unit_type, 0)
class UnitAction(Enum):
    IDLE = 0
    ATTACK = 1

# คลาสสำหรับยูนิต
class Unit:
    def __init__(self, unit_type: UnitType, x: int, y: int, player: int):
        # กำหนดค่าพื้นฐานของยูนิต
        self.unit_type = unit_type  # ประเภทของยูนิต
        self.x = x  # ตำแหน่ง x ของยูนิต
        self.y = y  # ตำแหน่ง y ของยูนิต
        self.player = player  # ผู้เล่นที่เป็นเจ้าของยูนิต
        self.moved = False  # สถานะการเคลื่อนที่
        self.attacked = False   # สถานะการโจมตี
        self.current_action = UnitAction.IDLE
        self.animation_frame = 0
        self.animation_timer = 0
        self.animation_delay = 100  
        
        info = unit_type.get_info()  # เรียกข้อมูลของยูนิต
        self.max_hp = info["max_hp"]  # HP สูงสุด
        self.attack = info["attack"]  # พลังโจมตี
        self.move_range = info["move_range"]  # ระยะทางที่สามารถเคลื่อนที่ได้
        self.attack_range = info["attack_range"]  # ระยะทางโจมตี
        self.hp = self.max_hp  # กำหนด HP เริ่มต้นให้เท่ากับ HP สูงสุด
        self.sprites = {
            UnitAction.IDLE: {
                1: pygame.image.load(f"sprites/unit{self.unit_type.value}_idle_blue.png").convert_alpha(),
                2: pygame.image.load(f"sprites/unit{self.unit_type.value}_idle_red.png").convert_alpha()
            },
            UnitAction.ATTACK: {
                1: pygame.image.load(f"sprites/unit{self.unit_type.value}_attack_blue.png").convert_alpha(),
                2: pygame.image.load(f"sprites/unit{self.unit_type.value}_attack_red.png").convert_alpha()
            }
        }
        self.frame_width = 32  # Adjust based on your sprite size
        self.frame_height = 32
        self.frames_per_action = 4
    def update_animation(self, dt):
        self.animation_timer += dt
        if self.animation_timer >= self.animation_delay:
            self.animation_timer = 0
            self.animation_frame = (self.animation_frame + 1) % self.frames_per_action
    def get_current_frame(self):
        current_sheet = self.sprites[self.current_action][self.player]
        x = self.animation_frame * self.frame_width
        y = 0  # Assuming horizontal sprite sheet
        frame = pygame.Surface((self.frame_width, self.frame_height), pygame.SRCALPHA)
        frame.blit(current_sheet, (0, 0), (x, y, self.frame_width, self.frame_height))
        return frame
    def start_attack_animation(self):
        self.current_action = UnitAction.ATTACK
        self.animation_frame = 0
        self.animation_timer = 0
    def upscale_sprite(self, surface, scale):
        """Upscale the sprite using pygame's scale2x function."""
        result = surface
        for _ in range(scale):
            result = pygame.transform.scale2x(result)
        return result
    def downscale_sprite(self, surface, scale):
        """Downscale the sprite while preserving pixel art style."""
        width = surface.get_width() // scale
        height = surface.get_height() // scale
        scaled = pygame.Surface((width, height), pygame.SRCALPHA)
        
        for x in range(width):
            for y in range(height):
                scaled.set_at((x, y), surface.get_at((x * scale, y * scale)))
        
        return scaled
    def draw(self, screen, tile_size):
        current_frame = self.get_current_frame()
        
        # Determine if we need to upscale or downscale
        if tile_size > self.frame_width:
            scale_factor = tile_size // self.frame_width
            scaled_frame = self.upscale_sprite(current_frame, scale_factor)
        elif tile_size < self.frame_width:
            scale_factor = self.frame_width // tile_size
            scaled_frame = self.downscale_sprite(current_frame, scale_factor)
        else:
            scaled_frame = current_frame
        # If the scaled size doesn't match the tile size exactly, do a final resize
        if scaled_frame.get_width() != tile_size:
            scaled_frame = pygame.transform.scale(scaled_frame, (tile_size, tile_size))

        screen.blit(scaled_frame, (self.x * tile_size, self.y * tile_size))

        if self.current_action == UnitAction.ATTACK and self.animation_frame == self.frames_per_action - 1:
            self.current_action = UnitAction.IDLE
    
    
    def __str__(self):
        return f"{self.unit_type.get_info()['name']} (HP: {self.hp}/{self.max_hp}, Attack: {self.attack})"
