<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="spritesheet" tilewidth="32" tileheight="32" tilecount="121" columns="11">
 <image source="isometric tileset/spritesheet.png" width="352" height="352"/>
</tileset>
