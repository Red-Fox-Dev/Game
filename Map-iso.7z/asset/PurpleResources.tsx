<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="PurpleResources" tilewidth="32" tileheight="16" tilecount="5" columns="1">
 <image source="../../Assest Game/MiniWorldSprites/Buildings/Purple/PurpleResources.png" width="48" height="80"/>
</tileset>
